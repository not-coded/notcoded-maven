package xyz.nucleoid.fantasy;

public interface FantasyWorldAccess {
    void fantasy$setTickWhenEmpty(boolean tickWhenEmpty);

    boolean fantasy$shouldTick();
}
